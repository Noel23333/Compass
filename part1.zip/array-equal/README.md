
# Array Equal

Check if two arrays are equal:

```js
var equals = require('array-equal')

assert(equals([1, 2, 3], [1, 2, 3])) // => true
assert(equals([1, 2, 3], [1, 2, 3, 4])) // => false
```
