Breaking changes are documented using GitHub issues, see [issues labeled "release notes"](https://github.com/hapijs/topo/issues?q=is%3Aissue+label%3A%22release+notes%22).

If you want changes of a specific minor or patch release, you can browse the [GitHub milestones](https://github.com/hapijs/topo/milestones?state=closed&direction=asc&sort=due_date).
