declare function accessor(): boolean;

export = accessor;