declare function getInferredName(key: PropertyKey): string;

declare const x: typeof getInferredName | undefined | null;

export = x;