# Changelog

All notable changes to this project will be documented in this file. See [standard-version](https://github.com/conventional-changelog/standard-version) for commit guidelines.

### [3.0.2](https://github.com/mightyiam/get-own-enumerable-property-symbols/compare/v3.0.1...v3.0.2) (2019-12-10)


### Bug Fixes

* add missing license file ([dbf11c2](https://github.com/mightyiam/get-own-enumerable-property-symbols/commit/dbf11c2b705dcfb42d6ac291f6608adb14ed6fd3)), closes [#87](https://github.com/mightyiam/get-own-enumerable-property-symbols/issues/87)

### [3.0.1](https://github.com/mightyiam/get-own-enumerable-property-symbols/compare/v3.0.0...v3.0.1) (2019-10-04)
