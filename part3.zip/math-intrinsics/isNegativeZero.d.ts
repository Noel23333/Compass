declare function isNegativeZero(x: unknown): boolean;

export = isNegativeZero;