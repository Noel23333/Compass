import { AsapAction } from './AsapAction';
import { AsapScheduler } from './AsapScheduler';
export const asapScheduler = new AsapScheduler(AsapAction);
export const asap = asapScheduler;
//# sourceMappingURL=asap.js.map