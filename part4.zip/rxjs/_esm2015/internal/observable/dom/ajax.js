import { AjaxObservable } from './AjaxObservable';
export const ajax = (() => AjaxObservable.create)();
//# sourceMappingURL=ajax.js.map