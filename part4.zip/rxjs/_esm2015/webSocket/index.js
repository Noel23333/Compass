export { webSocket as webSocket } from '../internal/observable/dom/webSocket';
export { WebSocketSubject } from '../internal/observable/dom/WebSocketSubject';
//# sourceMappingURL=index.js.map