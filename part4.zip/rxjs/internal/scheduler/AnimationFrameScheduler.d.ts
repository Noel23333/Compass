import { AsyncAction } from './AsyncAction';
import { AsyncScheduler } from './AsyncScheduler';
export declare class AnimationFrameScheduler extends AsyncScheduler {
    flush(action?: AsyncAction<any>): void;
}
