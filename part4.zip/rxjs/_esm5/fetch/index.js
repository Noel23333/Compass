/** PURE_IMPORTS_START  PURE_IMPORTS_END */
export { fromFetch } from '../internal/observable/dom/fetch';
//# sourceMappingURL=index.js.map
