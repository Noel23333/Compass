/** PURE_IMPORTS_START  PURE_IMPORTS_END */
export function hostReportError(err) {
    setTimeout(function () { throw err; }, 0);
}
//# sourceMappingURL=hostReportError.js.map
