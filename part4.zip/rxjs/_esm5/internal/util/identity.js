/** PURE_IMPORTS_START  PURE_IMPORTS_END */
export function identity(x) {
    return x;
}
//# sourceMappingURL=identity.js.map
