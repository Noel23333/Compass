/** PURE_IMPORTS_START  PURE_IMPORTS_END */
export function noop() { }
//# sourceMappingURL=noop.js.map
