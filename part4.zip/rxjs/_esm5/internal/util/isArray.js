/** PURE_IMPORTS_START  PURE_IMPORTS_END */
export var isArray = /*@__PURE__*/ (function () { return Array.isArray || (function (x) { return x && typeof x.length === 'number'; }); })();
//# sourceMappingURL=isArray.js.map
