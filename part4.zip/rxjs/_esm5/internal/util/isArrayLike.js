/** PURE_IMPORTS_START  PURE_IMPORTS_END */
export var isArrayLike = (function (x) { return x && typeof x.length === 'number' && typeof x !== 'function'; });
//# sourceMappingURL=isArrayLike.js.map
