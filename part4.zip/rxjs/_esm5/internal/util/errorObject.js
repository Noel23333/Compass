/** PURE_IMPORTS_START  PURE_IMPORTS_END */
export var errorObject = { e: {} };
//# sourceMappingURL=errorObject.js.map
